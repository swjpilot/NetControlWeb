// Auto-generated version file - do not edit manually
const version = {
  major: '1.0',
  build: '20260107_052048',
  timestamp: '2026-01-07T10:20:48.551Z',
  environment: process.env.NODE_ENV || 'production'
};
module.exports = version;
