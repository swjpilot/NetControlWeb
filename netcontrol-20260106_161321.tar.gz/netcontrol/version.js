// Auto-generated version file - do not edit manually
const version = {
  major: '1.0',
  build: '20260106_161321',
  timestamp: '2026-01-06T21:13:21.973Z',
  environment: process.env.NODE_ENV || 'production'
};
module.exports = version;
